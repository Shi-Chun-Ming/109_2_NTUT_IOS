//
//  Model.swift
//  lab09
//
//  Created by 徐雋銘 on 2021/5/19.
//

import Foundation

class model:ObservableObject
{
    @Published var player=1
    @Published var computer=1
    @Published var result="請按出拳開始猜拳"
}
