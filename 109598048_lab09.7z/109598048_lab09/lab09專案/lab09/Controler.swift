//
//  Controler.swift
//  lab09
//
//  Created by 徐雋銘 on 2021/5/19.
//

import Foundation

class controller:ObservableObject
{
  @Published var Model=model()
  @Published var start=0
 
   
    func PlayerAnswer()->Int
    {return Model.player}
    
    
    func ComputerAnswer()->Int
    {return Model.computer}
    
     func ResultAnswer()->String
     {return Model.result}
    
    func PtoStr()->String
    {
        var which=" "
        if(Model.player==1){which="剪刀"}
        if(Model.player==2){which="石頭"}
        if(Model.player==3){which="布"}
        return which
    }
    
    func CtoStr()->String
    {
        var which=" "
        if(Model.computer==1){which="剪刀"}
        if(Model.computer==2){which="石頭"}
        if(Model.computer==3){which="布"}
        return which
    }
    
    func play(){
        Model.player=Int.random(in: 1...3)
        Model.computer=Int.random(in: 1...3)
        start=1
        if(Model.player == Model.computer )
        {
            Model.result="平手"
        }
        else if(Model.player == 1 && Model.computer == 2)
        {
            Model.result="你輸了"
            
        }
        else if(Model.player == 2 && Model.computer == 3)
        {
            Model.result="你輸了"
            
        }
        else if(Model.player == 1 && Model.computer == 3)
        {
            Model.result="你贏了"
            
        }
        else if(Model.player == 2 && Model.computer == 1)
        {
            Model.result="你贏了"
            
        }
        else if(Model.player == 3 && Model.computer == 2)
        {
            Model.result="你贏了"
            
        }
        else if(Model.player == 3 && Model.computer == 1)
        {
            Model.result="你輸了"
        }
        
          }
}


