//
//  ContentView.swift
//  lab09
//
//  Created by 徐雋銘 on 2021/5/18.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var Control=controller()
    var body: some View {
        VStack
        {
            Text("猜拳遊戲") .font(.system(size:35)).fontWeight(.heavy).foregroundColor(Color.black).italic().padding();
           
            HStack
            {
                Text("玩家:         ");
                Image("\(Control.PlayerAnswer())")
                    .resizable()
                  .frame(width: 80.0, height: 80.0)
                Text("        \(Control.PtoStr())")
             }
            HStack
            {
                Text("電腦:         ");
                Image("\(Control.ComputerAnswer())")
                    .resizable()
                  .frame(width: 80.0, height: 80.0)
                Text("        \(Control.CtoStr())")
            }
            
            Button(action:{Control.play();},label:{
            ZStack{
                       Image("4")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 110, height: 110)
                        Text("出拳")
                        .font(.system(size:25)).fontWeight(.heavy)
                            .foregroundColor(Color.blue).italic().frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)}})
            
            HStack
            {
                Text("結果:     ");
                
                Text("   \(Control.ResultAnswer())")
                    .font(.system(size:25)).fontWeight(.heavy).foregroundColor(Color.red).italic()        }
}
    }
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
 }
}
