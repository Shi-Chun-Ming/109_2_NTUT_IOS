//
//  lab09App.swift
//  lab09
//
//  Created by 徐雋銘 on 2021/5/18.
//

import SwiftUI

@main
struct lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
