//
//  SecondPageIView.swift
//  lecture_05_03
//
//  Created by 徐雋銘 on 2021/5/2.
//

import SwiftUI


struct SecondPageIView: View {
    @Binding var ShowSecondPage:Bool
    @Binding var number:Int
    
    var body: some View {
     
        ZStack
        {
            
            Color.yellow.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack
            {
            Image("msi2")
                .resizable()
                .scaledToFit()
                .padding()
             Text("2021年英雄聯盟季中邀請賽是由拳頭遊戲主辦的第六屆英雄聯盟季中邀請賽，於5月6日至5月22日在冰島首都雷克雅維克舉行")
                .fontWeight(.bold)
                .font(.system(.largeTitle, design: .rounded))
                .multilineTextAlignment(.center)
                
            }
                
                }
        .overlay(
            Button(action: {
                ShowSecondPage=false
            },label:{
                Text("上一頁")
            }) ,alignment: .topTrailing)
        }
        
            
}
    

struct SecondPageIView_Previews: PreviewProvider {
    static var previews: some View {
        SecondPageIView(ShowSecondPage:.constant(true), number: .constant(0))
    }
}
