//
//  ForEachView.swift
//  lecture_05_03
//
//  Created by 徐雋銘 on 2021/5/4.
//

import SwiftUI
struct Song
{
    var name:String
    var singer:String
}

struct ForEachView: View {
    @Binding var thirdPage:Bool
    
    var songs=[
        Song(name: "LPL", singer:"RNG"),
        Song(name: "VCS", singer:"MAD Lions"),
        Song(name: "LCL", singer:"FlyQuest"),
        Song(name: "LCO", singer:"DAMWON Gaming"),
        Song(name: "LEC", singer:"Machi Esports"),
        Song(name: "PCS", singer:"PSG Talon"),
        Song(name: "TCL", singer:"Unicorns Of Love"),
        Song(name: "CBLOL", singer:"Legacy Esports"),
    ]
    

    var body: some View {
        
        ZStack
        {
            
            Color.purple.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack
            {
            Image("msi3")
                .resizable()
                .scaledToFit()
                .padding()
                VStack
                {
                    ForEach(songs,id: \.name)
                    {
                        song in
                        Text("\(song.name) by \(song.singer)")
                    }
                }
                
            }
                
        }
        .overlay(
            Button(action: {
                thirdPage=false
            },label:{
                Text("上一頁")
            }) ,alignment: .topTrailing)
        }
        
    }


struct ForEachView_Previews: PreviewProvider {
    static var previews: some View {
        ForEachView(thirdPage:.constant(true))
    }
}
