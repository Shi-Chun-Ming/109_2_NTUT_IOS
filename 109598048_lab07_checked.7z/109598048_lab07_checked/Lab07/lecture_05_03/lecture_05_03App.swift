//
//  lecture_05_03App.swift
//  lecture_05_03
//
//  Created by 徐雋銘 on 2021/5/2.
//

import SwiftUI

@main
struct lecture_05_03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
