//
//  ContentView.swift
//  lecture_05_03
//
//  Created by 徐雋銘 on 2021/5/2.
//

import SwiftUI

struct ContentView: View {
    @State private var showSecnodPage=false
    @State private var thirdPage=false
    @State var number=5
    
    var body: some View {
        VStack(spacing: 100)
        {
        Text("2021年英雄聯盟\n季中邀請賽\n冰島首都雷克雅維克")
        .fontWeight(.bold)
        .font(.system(.largeTitle, design: .rounded))
        .multilineTextAlignment(.center)
        VStack
        {
        Image("msI")
        .resizable()
        .scaledToFit()
            
        
        Button(action: {showSecnodPage=true}, label: {Text("比賽詳情")})  .fullScreenCover(isPresented: $showSecnodPage, content: {
        SecondPageIView(ShowSecondPage: $showSecnodPage, number: $number)
            })
            Button(action: {thirdPage=true}, label: {Text("參賽隊伍")})  .fullScreenCover(isPresented: $thirdPage, content: {
                ForEachView(thirdPage: $thirdPage)
                })
        }
        }

        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
