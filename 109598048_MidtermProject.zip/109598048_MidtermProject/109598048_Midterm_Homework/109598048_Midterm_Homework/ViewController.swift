//
//  ViewController.swift
//  109598048_Midterm_Homework
//
//  Created by 徐雋銘 on 2021/4/19.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Answer: UILabel!
    @IBOutlet weak var Process: UILabel!
    
    var modifier: String="n" //運算子區
    var input: String="0" // 輸入區
    var save: String="" //保存區
    var lastIsDot="no"//input出現過小數點了嗎
    var Buff=[String]()
    var buffCount=0
    var isequal=0 //已經按了等號嗎
    
    
    @IBAction func Numbers(_ sender: UIButton) {
        let inputNumber=sender.tag
        if(isequal==1)
        {
            ClearAll()
            isequal=0
        }
        if(modifier != "n")
        {
            updateInput()
            modifier="n"
        }
        
        if(beforeZero()==0){input="\(inputNumber)"}
        else{input+="\(inputNumber)"}
        Answer.text=input
        Process.text=save
        
    }
    
    @IBAction func AC(_ sender: UIButton) {
        ClearAll()
        isequal=0
    }
    @IBAction func PositiveOrNot(_ sender: UIButton)
    {
        if(isequal==1)
        {
            var temp2=calculator()
            ClearAll()
            input=temp2
            isequal=0
        }
        var isfloat=0
        for index in input.indices.reversed() {
            if(input[index] == "."){isfloat=1}
            
        }
        if(isfloat==1)
        {
            var temp=Float(input)!
            temp *= -1
            input="\(temp)"
            
        }
        if(isfloat==0)
        {
            var temp=Int(input)!
            temp *= -1
            input="\(temp)"
            
        }
      
        
        Answer.text=input
    }
    @IBAction func remainder(_ sender: UIButton) {
        if(isequal==1)
        {
            var temp2=calculator()
            ClearAll()
            input=temp2
            isequal=0
        }
        var temp=Float(input)!
        if(temp != 0)
        {
            temp /= 100
            input="\(temp)"
            Answer.text=input
        }
        
    }
    @IBAction func add(_ sender: UIButton) {
        if(isequal==1)
        {
            var temp=calculator()
            ClearAll()
            input=temp
            isequal=0
        }
        modifier="+"
        Answer.text="+"
        Process.text=save+afterZero(input: input)
        
    }
    @IBAction func Subtraction(_ sender: UIButton) {
        if(isequal==1)
        {
            var temp=calculator()
            ClearAll()
            input=temp
            isequal=0
        }
        modifier="-"
        Answer.text="-"
        Process.text=save+afterZero(input: input)
    }
    @IBAction func multiplication(_ sender: UIButton) {
        if(isequal==1)
        {
            var temp=calculator()
            ClearAll()
            input=temp
            isequal=0
        }
        modifier="X"
        Answer.text="X"
        Process.text=save+afterZero(input: input)
    }
    @IBAction func division(_ sender: UIButton) {
        if(isequal==1)
        {
            var temp=calculator()
            ClearAll()
            input=temp
            isequal=0
        }
        modifier="÷"
        Answer.text="÷"
        Process.text=save+afterZero(input: input)
    }
    @IBAction func Equal(_ sender: UIButton) {
        if(isequal==1)
        {
            ClearAll()
            isequal=0
        }
        else
        {
        modifier="="
        updateInput()
        Process.text=save+afterZero(input: input)+calculator()
        Answer.text=calculator()
        isequal=1
        }
        
    }
    @IBAction func Decimalpoint(_ sender: UIButton) {
        if(modifier == "n")
        {
            if(lastIsDot == "no" )
            {
             lastIsDot="yes"
             input+="."
             Answer.text=input
            }
        }
        
    }
    
    func ClearAll()
    {
        buffCount=0
        Buff.removeAll()
        lastIsDot="no"
        input="0"
        save=""
        modifier="n"
        Answer.text=input
        Process.text=" "
    }
    
    func updateInput() {
        if(lastIsDot != "no")
        {
            lastIsDot="no"
            save+=afterZero(input: input)+modifier
            
             buffCount += 2;
            Buff.append(afterZero(input: input))
             Buff.append(modifier)
                
            input="0"
        }
        else
        {
         lastIsDot="no"
         save+=input+modifier
            
         buffCount += 2;
         Buff.append(input)
         Buff.append(modifier)
            
         input="0"
        }
    }
    
    func afterZero(input:String)->String //判斷小數點後多餘的0
   {
   
    var temp=""
    var temp2=""
    var check=0;
    for index in input.indices.reversed() {
        if(input[index] != "0" && input[index] != "." ){check=1}
        if(check == 1)
        {
            temp += ("\(input[index])")
        }
        if(input[index] == "." && check==0){check=1}
    }
    for index in temp.indices.reversed()
    {
        temp2+=("\(temp[index])")
    }
        
    return temp2
   }
   
    func beforeZero()->Int //判斷前面多餘的0
    {
        var count=0 //目前input的非0個數
        for index in input.indices {
            var temp=("\(input[index])")
            if(temp != "0"){count=1}
        }
        return count
    }
    
    
    func calculator()->String
    {
        var HowMuchModifier=0
        var HowMuchAddSub=0
        var sum:Float
        sum=0
                for numbers in 0...buffCount-1
                {
                    if(Buff[numbers] == "X"){HowMuchModifier += 1}
                    if(Buff[numbers] == "÷"){HowMuchModifier += 1}
                    if(Buff[numbers] == "+"){HowMuchAddSub += 1}
                    if(Buff[numbers] == "-"){HowMuchAddSub += 1}
                }
              if(HowMuchModifier != 0)
              {
                for index in 1...HowMuchModifier
                {
                    var temp = [String]()
                    var tempCount=0
                    for numbers2 in 0...buffCount-1
                    {
                        temp.append("n")
                    }
                    for numbers in 0...buffCount-1
                    {
                        if(Buff[numbers] == "X")
                        {
                            Buff[numbers-1]=("\(Float(Buff[numbers-1])!*Float(Buff[numbers+1])!)")
                            Buff[numbers+1]="n"
                            Buff[numbers]="n"
                            
                            break
                        }
                        else if(Buff[numbers] == "÷")
                        {
                            if(Buff[numbers+1]=="0")
                            {
                                Buff[numbers-1]="\(Float(0))"
                                Buff[numbers+1]="n"
                                Buff[numbers]="n"
                                break
                            }
                            else
                            {
                            
                              Buff[numbers-1]=("\(Float(Buff[numbers-1])!/Float(Buff[numbers+1])!)")
                              Buff[numbers+1]="n"
                              Buff[numbers]="n"
                              break
                            
                          }
                        }

                    }
                    for numbers in 0...buffCount-1
                    {
                        if(Buff[numbers] != "n")
                        {
                            temp[tempCount]=Buff[numbers]
                            tempCount += 1
                        }
                    }
                    
                    for numbers in 0...tempCount
                    {
                        Buff[numbers]=temp[numbers]
                    }
                    buffCount -= (buffCount-tempCount)
                    
                }
              }
        
                for index in 0...buffCount-1
                {
                    if(index == 0){sum=Float(Buff[index])!}
                    if(Buff[index] == "+"){sum += Float(Buff[index+1])!}
                    if(Buff[index] == "-"){sum -= Float(Buff[index+1])!}
                    
                }
        
        var end="\(sum)"
        var a=0

        for index in end.indices.reversed() {
            
            if(a==1 && "\(end[index])" == "."){
                end="\(Int(sum))"
                break
            }
            if(a==0 && "\(end[index])" == "0"){}
            else{a=5}
            
            
            a += 1
        }
               
       return end
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

